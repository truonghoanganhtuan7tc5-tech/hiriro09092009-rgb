package com.jolliebear.model;

/**
 * Model dữ liệu cho 1 chương trình Khuyến Mãi.
 * Sau này có thể map trực tiếp sang 1 row trong bảng DB "promotions".
 */
public class Promotion {

    private int id;
    private String badgeText;      // Nhãn góc thẻ: "-50%", "MUA 1 TẶNG 1"...
    private String label;          // Nhãn nhỏ phía trên tiêu đề: "COMBO TIẾT KIỆM"
    private String title;          // Tiêu đề chính
    private String description;    // Mô tả ngắn
    private String priceNew;       // Giá sau khuyến mãi (hiển thị, VD "59.000đ")
    private String priceOld;       // Giá gốc (có thể null nếu không áp dụng)
    private String iconClass;      // Class icon Font Awesome, VD "fa-solid fa-bucket"
    private String iconBgClass;    // Class CSS nền icon: combo-icon / spicy-icon / student-icon / ship-icon
    private String buttonText;     // Text nút hành động
    private String buttonLink;     // Link nút hành động

    public Promotion() {
    }

    public Promotion(int id, String badgeText, String label, String title, String description,
                      String priceNew, String priceOld, String iconClass, String iconBgClass,
                      String buttonText, String buttonLink) {
        this.id = id;
        this.badgeText = badgeText;
        this.label = label;
        this.title = title;
        this.description = description;
        this.priceNew = priceNew;
        this.priceOld = priceOld;
        this.iconClass = iconClass;
        this.iconBgClass = iconBgClass;
        this.buttonText = buttonText;
        this.buttonLink = buttonLink;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getBadgeText() { return badgeText; }
    public void setBadgeText(String badgeText) { this.badgeText = badgeText; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getPriceNew() { return priceNew; }
    public void setPriceNew(String priceNew) { this.priceNew = priceNew; }

    public String getPriceOld() { return priceOld; }
    public void setPriceOld(String priceOld) { this.priceOld = priceOld; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public String getIconBgClass() { return iconBgClass; }
    public void setIconBgClass(String iconBgClass) { this.iconBgClass = iconBgClass; }

    public String getButtonText() { return buttonText; }
    public void setButtonText(String buttonText) { this.buttonText = buttonText; }

    public String getButtonLink() { return buttonLink; }
    public void setButtonLink(String buttonLink) { this.buttonLink = buttonLink; }
}
