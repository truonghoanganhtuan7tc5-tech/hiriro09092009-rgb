package com.jolliebear.model;

/**
 * Model dữ liệu cho 1 Dịch Vụ.
 * Sau này có thể map trực tiếp sang 1 row trong bảng DB "services".
 */
public class ServiceItem {

    private int id;
    private String iconClass;   // Class icon Font Awesome, VD "fa-solid fa-motorcycle"
    private String title;       // Tên dịch vụ
    private String description; // Mô tả ngắn
    private String linkText;    // Text link hành động
    private String link;        // URL / route xử lý dịch vụ

    public ServiceItem() {
    }

    public ServiceItem(int id, String iconClass, String title, String description,
                        String linkText, String link) {
        this.id = id;
        this.iconClass = iconClass;
        this.title = title;
        this.description = description;
        this.linkText = linkText;
        this.link = link;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getLinkText() { return linkText; }
    public void setLinkText(String linkText) { this.linkText = linkText; }

    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }
}
