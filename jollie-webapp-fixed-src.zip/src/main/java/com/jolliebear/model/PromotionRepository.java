package com.jolliebear.model;

import java.util.ArrayList;
import java.util.List;

/**
 * "Nguồn dữ liệu" khuyến mãi.
 * Hiện đang trả về danh sách cứng (in-memory) để demo Servlet + JSP.
 * Khi có Database, chỉ cần thay nội dung method findAll() bằng truy vấn JDBC/DAO,
 * phần Servlet và JSP KHÔNG cần sửa gì thêm.
 */
public class PromotionRepository {

    public List<Promotion> findAll() {
        List<Promotion> list = new ArrayList<>();

        list.add(new Promotion(
                1, "-50%", "COMBO TIẾT KIỆM", "Combo Gà Giòn 2 Miếng",
                "Bao gồm 2 miếng gà giòn, 1 cơm, 1 nước ngọt size vừa.",
                "59.000đ", "118.000đ",
                "fa-solid fa-bucket", "combo-icon",
                "Đặt ngay", "menu"
        ));

        list.add(new Promotion(
                2, "MUA 1 TẶNG 1", "ƯU ĐÃI THỨ 4", "Gà Sốt Cay Mua 1 Tặng 1",
                "Áp dụng cho đơn đặt qua ứng dụng, thứ 4 hàng tuần.",
                "39.000đ", "78.000đ",
                "fa-solid fa-pepper-hot", "spicy-icon",
                "Đặt ngay", "menu"
        ));

        list.add(new Promotion(
                3, "SINH VIÊN", "ƯU ĐÃI HỌC SINH SV", "Giảm 20% Toàn Thực Đơn",
                "Chỉ cần xuất trình thẻ học sinh, sinh viên khi thanh toán.",
                "Giảm 20%", null,
                "fa-solid fa-graduation-cap", "student-icon",
                "Xem chi tiết", "menu"
        ));

        list.add(new Promotion(
                4, "FREESHIP", "GIAO HÀNG TẬN NƠI", "Miễn Phí Giao Hàng",
                "Cho đơn hàng từ 99.000đ trong bán kính 3km.",
                "0đ Ship", null,
                "fa-solid fa-motorcycle", "ship-icon",
                "Đặt ngay", "menu"
        ));

        return list;
    }
}
