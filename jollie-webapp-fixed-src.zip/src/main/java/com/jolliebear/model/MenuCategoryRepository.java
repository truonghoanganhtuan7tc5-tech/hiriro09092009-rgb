package com.jolliebear.model;

import java.util.ArrayList;
import java.util.List;

public class MenuCategoryRepository {

    public List<MenuCategory> findAll() {
        List<MenuCategory> list = new ArrayList<>();

        list.add(new MenuCategory(1, "fa-solid fa-drumstick-bite", "chicken-mock",
                "Gà Giòn Vui Vẻ", "Thơm giòn rụm bên ngoài, mọng nước bên trong.", "menu?cat=chicken"));

        list.add(new MenuCategory(2, "fa-solid fa-fire-flame-curved", "spicy-mock",
                "Gà Sốt Cay & Ngọt", "Sốt đặc trưng thấm sâu cay tê kích thích vị giác.", "menu?cat=spicy"));

        list.add(new MenuCategory(3, "fa-solid fa-bowl-food", "spaghetti-mock",
                "Mỳ Ý Sốt Bò Bằm", "Mỳ dai mềm kết hợp sốt thịt băm đậm đà.", "menu?cat=spaghetti"));

        list.add(new MenuCategory(4, "fa-solid fa-ice-cream", "dessert-mock",
                "Tráng Miệng Ngọt Ngào", "Kem tươi mát lạnh, giải nhiệt ngày hè.", "menu?cat=dessert"));

        return list;
    }
}
