package com.jolliebear.model;

/**
 * Model dữ liệu cho 1 Danh Mục Món Ăn ("Ăn Gì Hôm Nay").
 */
public class MenuCategory {

    private int id;
    private String iconClass;   // Icon Font Awesome hiển thị trong ảnh mock, VD "fa-solid fa-drumstick-bite"
    private String bgClass;     // Class CSS nền ảnh: chicken-mock / spicy-mock / spaghetti-mock / dessert-mock
    private String title;
    private String description;
    private String link;

    public MenuCategory() {
    }

    public MenuCategory(int id, String iconClass, String bgClass, String title, String description, String link) {
        this.id = id;
        this.iconClass = iconClass;
        this.bgClass = bgClass;
        this.title = title;
        this.description = description;
        this.link = link;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public String getBgClass() { return bgClass; }
    public void setBgClass(String bgClass) { this.bgClass = bgClass; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }
}
