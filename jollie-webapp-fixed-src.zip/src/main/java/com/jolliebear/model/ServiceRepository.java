package com.jolliebear.model;

import java.util.ArrayList;
import java.util.List;

/**
 * "Nguồn dữ liệu" dịch vụ.
 * Hiện đang trả về danh sách cứng (in-memory) để demo Servlet + JSP.
 * Khi có Database, chỉ cần thay nội dung method findAll() bằng truy vấn JDBC/DAO.
 */
public class ServiceRepository {

    public List<ServiceItem> findAll() {
        List<ServiceItem> list = new ArrayList<>();

        list.add(new ServiceItem(
                1, "fa-solid fa-motorcycle", "Giao Hàng Tận Nơi",
                "Đặt món yêu thích và nhận hàng ngay tại nhà chỉ trong 30 phút.",
                "Đặt giao hàng", "service?type=delivery"
        ));

        list.add(new ServiceItem(
                2, "fa-solid fa-bag-shopping", "Đặt Đến Lấy",
                "Đặt trước trên app, ghé cửa hàng lấy ngay, không cần chờ đợi.",
                "Đặt đến lấy", "service?type=pickup"
        ));

        list.add(new ServiceItem(
                3, "fa-solid fa-champagne-glasses", "Tổ Chức Tiệc & Sự Kiện",
                "Không gian ấm cúng, phù hợp tổ chức sinh nhật, tiệc nhóm bạn bè.",
                "Liên hệ đặt tiệc", "service?type=party"
        ));

        list.add(new ServiceItem(
                4, "fa-solid fa-building", "Đặt Suất Ăn Doanh Nghiệp",
                "Giải pháp suất ăn số lượng lớn cho công ty, hội nghị, sự kiện.",
                "Nhận báo giá", "service?type=corporate"
        ));

        list.add(new ServiceItem(
                5, "fa-solid fa-mobile-screen-button", "Đặt Hàng Qua App",
                "Tải ứng dụng Jolliebear để tích điểm và nhận ưu đãi độc quyền.",
                "Tải ứng dụng", "service?type=app"
        ));

        list.add(new ServiceItem(
                6, "fa-solid fa-headset", "Hỗ Trợ Khách Hàng 24/7",
                "Đội ngũ CSKH luôn sẵn sàng giải đáp mọi thắc mắc của bạn.",
                "Liên hệ hotline", "service?type=support"
        ));

        return list;
    }
}
