package com.jolliebear.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Xử lý khi người dùng bấm vào 1 dịch vụ cụ thể (Giao hàng, Đặt đến lấy, Tổ chức tiệc...).
 * Mapping: /service?type=delivery|pickup|party|corporate|app|support
 *
 * Đây chỉ là bản demo hiển thị thông báo tương ứng.
 * Sau này có thể thay bằng logic thật: tạo đơn hàng, chuyển trang đặt lịch, v.v.
 */
@WebServlet(name = "ServiceActionServlet", urlPatterns = {"/service"})
public class ServiceActionServlet extends HttpServlet {

    private static final Map<String, String> SERVICE_MESSAGES = new HashMap<>();
    static {
        SERVICE_MESSAGES.put("delivery", "Vui lòng nhập địa chỉ để bắt đầu đặt giao hàng tận nơi.");
        SERVICE_MESSAGES.put("pickup", "Chọn cửa hàng gần bạn nhất để đặt đến lấy.");
        SERVICE_MESSAGES.put("party", "Đội ngũ Jolliebear sẽ liên hệ tư vấn tổ chức tiệc trong 24h.");
        SERVICE_MESSAGES.put("corporate", "Vui lòng để lại thông tin để nhận báo giá suất ăn doanh nghiệp.");
        SERVICE_MESSAGES.put("app", "Quét mã QR hoặc tìm 'Jolliebear' trên App Store / CH Play để tải ứng dụng.");
        SERVICE_MESSAGES.put("support", "Gọi ngay hotline 1900 8080 để được hỗ trợ 24/7.");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String type = request.getParameter("type");
        String message = SERVICE_MESSAGES.getOrDefault(type, "Dịch vụ hiện chưa có thông tin chi tiết.");

        request.setAttribute("serviceType", type);
        request.setAttribute("serviceMessage", message);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/serviceResult.jsp");
        dispatcher.forward(request, response);
    }
}
