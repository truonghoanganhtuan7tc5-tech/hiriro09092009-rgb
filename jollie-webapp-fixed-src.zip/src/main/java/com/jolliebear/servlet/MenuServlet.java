package com.jolliebear.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Xử lý khi người dùng bấm "Xem thực đơn" của 1 danh mục món ăn.
 * Mapping: /menu?cat=chicken|spicy|spaghetti|dessert
 *
 * Bản demo chỉ hiển thị tên danh mục đã chọn.
 * Sau này có thể thay bằng danh sách món ăn thật (MenuItemRepository) lọc theo category.
 */
@WebServlet(name = "MenuServlet", urlPatterns = {"/menu"})
public class MenuServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String cat = request.getParameter("cat");
        request.setAttribute("selectedCategory", cat == null ? "tất cả" : cat);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/menuResult.jsp");
        dispatcher.forward(request, response);
    }
}
