<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - Giao Hàng Tận Nơi & Thực Đơn Thơm Ngon</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

    <!-- TOP UTILITY BAR -->
    <div class="utility-bar">
        <div class="utility-container">
            <div class="utility-left"><span>Chào mừng bạn đến với Jolliebear!</span></div>
            <div class="utility-right">
                <div class="language-selector">
                    <span class="lang-item active" id="lang-vi"><span class="flag-icon vi-flag"></span> VN</span>
                    <span class="lang-item" id="lang-en"><span class="flag-icon en-flag"></span> EN</span>
                </div>
                <a href="#login" class="auth-btn"><i class="fa-regular fa-user"></i><span>ĐĂNG KÝ / ĐĂNG NHẬP</span></a>
            </div>
        </div>
    </div>

    <!-- MAIN HEADER & NAVIGATION -->
    <header class="main-header">
        <div class="header-container">
            <a href="${pageContext.request.contextPath}/" class="logo-area">
                <div class="logo-circle"><i class="fa-solid fa-paw logo-icon"></i></div>
                <div class="logo-text">
                    <span class="logo-brand">Jolliebear</span>
                    <span class="logo-slogan">I'm lovin' it</span>
                </div>
            </a>
            <nav class="navbar">
                <ul class="nav-menu">
                    <li class="nav-item"><a href="#home" class="nav-link active">TRANG CHỦ</a></li>
                    <li class="nav-item"><a href="#about" class="nav-link">VỀ JOLLIEBEAR</a></li>
                    <li class="nav-item"><a href="#menu" class="nav-link">THỰC ĐƠN</a></li>
                    <li class="nav-item"><a href="#promotions" class="nav-link">KHUYẾN MÃI</a></li>
                    <li class="nav-item"><a href="#services" class="nav-link">DỊCH VỤ</a></li>
                    <li class="nav-item"><a href="#news" class="nav-link">TIN TỨC</a></li>
                    <li class="nav-item"><a href="#stores" class="nav-link">CỬA HÀNG</a></li>
                    <li class="nav-item"><a href="#contact" class="nav-link">LIÊN HỆ</a></li>
                    <li class="nav-item"><a href="#jobs" class="nav-link">TUYỂN DỤNG</a></li>
                </ul>
            </nav>
            <button class="mobile-nav-toggle" aria-label="Toggle navigation"><i class="fa-solid fa-bars"></i></button>
        </div>
    </header>

    <!-- HERO (giữ nguyên tĩnh) -->
    <section class="hero-carousel" id="home">
        <div class="carousel-track-container">
            <ul class="carousel-track">
                <li class="carousel-slide current-slide">
                    <div class="slide-content bg-gradient-1">
                        <div class="slide-inner">
                            <div class="slide-text">
                                <span class="badge">BÁN CHẠY NHẤT</span>
                                <h2>Gà Giòn Vui Vẻ</h2>
                                <p>Giòn rụm từng miếng, thơm ngon đậm đà chuẩn vị Jolliebear. Thử ngay hôm nay!</p>
                                <div class="price-tag"><span class="price">35.000đ</span> <span class="unit">/ Phần</span></div>
                                <a href="#menu" class="btn btn-primary">Đặt hàng ngay <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                            <div class="slide-graphic">
                                <div class="food-plate chicken-plate">
                                    <span class="graphic-shadow"></span>
                                    <i class="fa-solid fa-drumstick-bite graphic-food-icon animate-float"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="carousel-nav">
            <button class="carousel-indicator current-slide-indicator" aria-label="Slide 1"></button>
        </div>
    </section>

    <!-- ĐẶT HÀNG: GIAO TẬN NƠI / ĐẾN LẤY (giữ nguyên tĩnh - form nhập địa chỉ) -->
    <section class="order-section">
        <div class="order-container">
            <div class="order-toggle-wrapper">
                <button class="toggle-btn active" id="delivery-toggle">
                    <i class="fa-solid fa-motorcycle"></i> GIAO HÀNG TẬN NƠI
                </button>
                <button class="toggle-btn" id="pickup-toggle">
                    <i class="fa-solid fa-store"></i> ĐẶT ĐẾN LẤY
                </button>
            </div>
            <div class="address-search-box">
                <div class="input-wrapper">
                    <i class="fa-solid fa-location-dot input-loc-icon"></i>
                    <input type="text" id="address-input" placeholder="Nhập địa chỉ giao hàng của bạn..." aria-label="Nhập địa chỉ giao hàng">
                    <button class="search-btn" aria-label="Tìm kiếm địa chỉ">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- "ĂN GÌ HÔM NAY" - DỮ LIỆU ĐỘNG TỪ SERVLET (request scope: menuCategories) -->
    <section class="featured-section" id="menu">
        <div class="featured-container">
            <div class="promo-brand-card">
                <div class="promo-content">
                    <div class="brand-mascot-wrapper"><i class="fa-solid fa-paw mascot-icon"></i></div>
                    <h2>ĂN GÌ HÔM NAY</h2>
                    <p>Thực đơn Jolliebear đa dạng và phong phú, có rất nhiều sự lựa chọn cho bạn, gia đình và bạn bè.</p>
                </div>
            </div>

            <div class="category-cards-grid">
                <c:forEach items="${menuCategories}" var="m">
                    <div class="category-card wood-card">
                        <div class="card-image-wrapper">
                            <div class="food-mock-img ${m.bgClass}">
                                <i class="${m.iconClass} food-mock-icon"></i>
                            </div>
                        </div>
                        <div class="card-info">
                            <h3>${m.title}</h3>
                            <p>${m.description}</p>
                            <a href="${pageContext.request.contextPath}/${m.link}" class="card-link">
                                Xem thực đơn <i class="fa-solid fa-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                </c:forEach>

                <c:if test="${empty menuCategories}">
                    <p>Hiện chưa có danh mục món ăn nào.</p>
                </c:if>
            </div>
        </div>
    </section>

    <!-- KHUYẾN MÃI - DỮ LIỆU ĐỘNG TỪ SERVLET (request scope: promotions) -->
    <section class="promo-section" id="promotions">
        <div class="promo-section-container">
            <div class="section-heading">
                <span class="section-tag">ƯU ĐÃI HÔM NAY</span>
                <h2>KHUYẾN MÃI HOT</h2>
                <p>Đừng bỏ lỡ những ưu đãi giòn rụm, tiết kiệm siêu đã dành riêng cho bạn</p>
            </div>

            <div class="promo-countdown-banner">
                <div class="countdown-left">
                    <i class="fa-solid fa-bolt countdown-icon"></i>
                    <div>
                        <h3>FLASH SALE CUỐI TUẦN</h3>
                        <p>Giảm ngay đến 50% cho mọi combo gà giòn</p>
                    </div>
                </div>
                <div class="countdown-timer" id="promo-countdown">
                    <div class="time-box"><span id="cd-hours">00</span><small>Giờ</small></div>
                    <div class="time-box"><span id="cd-minutes">00</span><small>Phút</small></div>
                    <div class="time-box"><span id="cd-seconds">00</span><small>Giây</small></div>
                </div>
            </div>

            <div class="promo-cards-grid">
                <c:forEach items="${promotions}" var="p">
                    <div class="promo-card">
                        <div class="promo-discount-badge">${p.badgeText}</div>
                        <div class="promo-card-icon ${p.iconBgClass}">
                            <i class="${p.iconClass}"></i>
                        </div>
                        <div class="promo-card-body">
                            <span class="promo-label">${p.label}</span>
                            <h3>${p.title}</h3>
                            <p>${p.description}</p>
                            <div class="promo-price-row">
                                <span class="promo-price-new">${p.priceNew}</span>
                                <c:if test="${not empty p.priceOld}">
                                    <span class="promo-price-old">${p.priceOld}</span>
                                </c:if>
                            </div>
                            <a href="${pageContext.request.contextPath}/${p.buttonLink}" class="btn btn-primary btn-block">${p.buttonText}</a>
                        </div>
                    </div>
                </c:forEach>

                <c:if test="${empty promotions}">
                    <p>Hiện chưa có chương trình khuyến mãi nào.</p>
                </c:if>
            </div>
        </div>
    </section>

    <!-- DỊCH VỤ - DỮ LIỆU ĐỘNG TỪ SERVLET (request scope: services) -->
    <section class="services-section" id="services">
        <div class="services-container">
            <div class="section-heading light-heading">
                <span class="section-tag">TRẢI NGHIỆM JOLLIEBEAR</span>
                <h2>DỊCH VỤ CỦA CHÚNG TÔI</h2>
                <p>Jolliebear luôn đồng hành cùng bạn với nhiều hình thức phục vụ tiện lợi nhất</p>
            </div>

            <div class="services-grid">
                <c:forEach items="${services}" var="s">
                    <div class="service-card">
                        <div class="service-icon-wrap"><i class="${s.iconClass}"></i></div>
                        <h3>${s.title}</h3>
                        <p>${s.description}</p>
                        <a href="${pageContext.request.contextPath}/${s.link}" class="service-link">
                            ${s.linkText} <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </c:forEach>

                <c:if test="${empty services}">
                    <p>Hiện chưa có dịch vụ nào.</p>
                </c:if>
            </div>
        </div>
    </section>

    <!-- FOOTER SECTION (giữ nguyên tĩnh) -->
    <footer class="site-footer">
        <div class="footer-container">
            <div class="footer-top">
                <div class="footer-brand">
                    <div class="footer-logo"><i class="fa-solid fa-paw"></i> Jolliebear</div>
                    <p class="footer-desc">Mang hương vị ngập tràn niềm vui tới mọi gia đình Việt Nam.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                        <a href="#" aria-label="Youtube"><i class="fa-brands fa-youtube"></i></a>
                        <a href="#" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                    </div>
                </div>
                <div class="footer-links-group">
                    <h4>LIÊN KẾT NHANH</h4>
                    <ul>
                        <li><a href="#about">Về Jolliebear</a></li>
                        <li><a href="#promotions">Tin Khuyến Mãi</a></li>
                        <li><a href="#services">Dịch Vụ</a></li>
                    </ul>
                </div>
                <div class="footer-links-group">
                    <h4>LIÊN HỆ</h4>
                    <ul>
                        <li><i class="fa-solid fa-phone"></i> Hotline: 1900 8080</li>
                        <li><i class="fa-solid fa-envelope"></i> Email: feedback@jolliebear.com.vn</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 Jolliebear Việt Nam.</p>
            </div>
        </div>
    </footer>

    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
