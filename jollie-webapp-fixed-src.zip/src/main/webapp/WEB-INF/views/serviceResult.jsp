<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Jolliebear - Kết quả dịch vụ</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        .result-wrap {
            max-width: 600px;
            margin: 100px auto;
            text-align: center;
            padding: 40px;
            background: var(--bg-white);
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-md);
        }
        .result-wrap i { font-size: 3rem; color: var(--primary); margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="result-wrap">
        <i class="fa-solid fa-circle-check"></i>
        <h2>Yêu cầu dịch vụ: ${serviceType}</h2>
        <p>${serviceMessage}</p>
        <br>
        <a href="${pageContext.request.contextPath}/#services" class="btn btn-primary">Quay lại Dịch Vụ</a>
    </div>
</body>
</html>
