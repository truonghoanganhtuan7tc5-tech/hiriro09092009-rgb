/**
 * Jolliebear Web Layout Interaction Script
 */

document.addEventListener('DOMContentLoaded', () => {
    
    // ==========================================
    // 0. SMOOTH SCROLL CHO CÁC LINK NEO (#menu, #promotions, #services...)
    //    Chặn hành vi mặc định (đổi URL hash) để tránh cảnh báo
    //    "Open external link" trên môi trường xem trước dạng iframe.
    // ==========================================
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
        anchor.addEventListener('click', (e) => {
            const targetId = anchor.getAttribute('href').slice(1);
            const targetEl = document.getElementById(targetId);
            if (targetEl) {
                e.preventDefault();
                targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // ==========================================
    // 1. MOBILE NAVIGATION TOGGLE
    // ==========================================
    const navToggle = document.querySelector('.mobile-nav-toggle');
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelectorAll('.nav-link');

    if (navToggle && navbar) {
        navToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            navbar.classList.toggle('open');
            const isOpen = navbar.classList.contains('open');
            navToggle.innerHTML = isOpen ? '<i class="fa-solid fa-xmark"></i>' : '<i class="fa-solid fa-bars"></i>';
        });

        // Close menu on link click
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navbar.classList.remove('open');
                navToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!navbar.contains(e.target) && !navToggle.contains(e.target)) {
                navbar.classList.remove('open');
                navToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
            }
        });
    }

    // ==========================================
    // 2. HEADER SCROLL EFFECT
    // ==========================================
    const header = document.querySelector('.main-header');
    
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    // ==========================================
    // 3. HERO CAROUSEL LOGIC
    // ==========================================
    const track = document.querySelector('.carousel-track');
    const slides = Array.from(document.querySelectorAll('.carousel-slide'));
    const indicators = Array.from(document.querySelectorAll('.carousel-indicator'));
    
    let currentSlideIndex = 0;
    let carouselInterval;
    const slideDuration = 5000; // 5 seconds

    const moveToSlide = (targetIndex) => {
        if (!slides.length) return;
        
        // Remove current classes
        slides[currentSlideIndex].classList.remove('current-slide');
        indicators[currentSlideIndex].classList.remove('current-slide-indicator');
        
        // Add classes to target
        slides[targetIndex].classList.add('current-slide');
        indicators[targetIndex].classList.add('current-slide-indicator');
        
        currentSlideIndex = targetIndex;
    };

    const startCarousel = () => {
        stopCarousel();
        carouselInterval = setInterval(() => {
            let nextIndex = (currentSlideIndex + 1) % slides.length;
            moveToSlide(nextIndex);
        }, slideDuration);
    };

    const stopCarousel = () => {
        if (carouselInterval) clearInterval(carouselInterval);
    };

    // Add click listeners to indicators
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            moveToSlide(index);
            startCarousel(); // Reset timer on manual navigation
        });
    });

    // Start auto slide
    if (slides.length > 0) {
        startCarousel();
        
        // Pause carousel when user hovers over the slider
        const heroSection = document.querySelector('.hero-carousel');
        if (heroSection) {
            heroSection.addEventListener('mouseenter', stopCarousel);
            heroSection.addEventListener('mouseleave', startCarousel);
        }
    }

    // ==========================================
    // 4. ORDER METHOD TOGGLE (Giao hàng / Đặt đến lấy)
    // ==========================================
    const deliveryToggle = document.getElementById('delivery-toggle');
    const pickupToggle = document.getElementById('pickup-toggle');
    const addressInput = document.getElementById('address-input');

    if (deliveryToggle && pickupToggle && addressInput) {
        deliveryToggle.addEventListener('click', () => {
            deliveryToggle.classList.add('active');
            pickupToggle.classList.remove('active');
            addressInput.placeholder = 'Nhập địa chỉ giao hàng của bạn...';
            // Focus input
            addressInput.focus();
        });

        pickupToggle.addEventListener('click', () => {
            pickupToggle.classList.add('active');
            deliveryToggle.classList.remove('active');
            addressInput.placeholder = 'Nhập địa chỉ cửa hàng hoặc khu vực muốn lấy hàng...';
            // Focus input
            addressInput.focus();
        });
    }

    // ==========================================
    // 5. LANGUAGE SELECTOR
    // ==========================================
    const langVi = document.getElementById('lang-vi');
    const langEn = document.getElementById('lang-en');

    if (langVi && langEn) {
        langVi.addEventListener('click', () => {
            langVi.classList.add('active');
            langEn.classList.remove('active');
            // Mock translation logic could go here
            console.log('Language switched to Vietnamese');
        });

        langEn.addEventListener('click', () => {
            langEn.classList.add('active');
            langVi.classList.remove('active');
            console.log('Language switched to English');
        });
    }

    // ==========================================
    // 6. COOKIE CONSENT BANNER
    // ==========================================
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const settingsBtn = document.getElementById('cookie-settings');

    if (cookieBanner && acceptBtn && declineBtn) {
        // Show cookie banner after 1.5 seconds if consent not set
        const isConsentGiven = localStorage.getItem('cookie-consent');
        if (!isConsentGiven) {
            setTimeout(() => {
                cookieBanner.classList.add('show');
            }, 1500);
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem('cookie-consent', 'accepted');
            cookieBanner.classList.remove('show');
            console.log('Cookie consent accepted');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem('cookie-consent', 'declined');
            cookieBanner.classList.remove('show');
            console.log('Cookie consent declined');
        });

        if (settingsBtn) {
            settingsBtn.addEventListener('click', () => {
                alert('Tùy chỉnh cookie: Hệ thống sẽ tự động cấu hình các tùy chọn tối ưu nhất.');
                localStorage.setItem('cookie-consent', 'customized');
                cookieBanner.classList.remove('show');
            });
        }
    }

    /* ==========================================================================
       PROMOTIONS COUNTDOWN TIMER (KHUYẾN MÃI)
       ========================================================================== */
    const cdHours = document.getElementById('cd-hours');
    const cdMinutes = document.getElementById('cd-minutes');
    const cdSeconds = document.getElementById('cd-seconds');

    if (cdHours && cdMinutes && cdSeconds) {
        // Đếm ngược tới 23:59:59 Chủ Nhật gần nhất (kết thúc flash sale cuối tuần)
        function getEndOfWeekTarget() {
            const now = new Date();
            const target = new Date(now);
            const daysUntilSunday = (7 - now.getDay()) % 7;
            target.setDate(now.getDate() + daysUntilSunday);
            target.setHours(23, 59, 59, 0);
            if (target <= now) {
                target.setDate(target.getDate() + 7);
            }
            return target;
        }

        let countdownTarget = getEndOfWeekTarget();

        function pad(num) {
            return String(num).padStart(2, '0');
        }

        function updateCountdown() {
            const now = new Date().getTime();
            let distance = countdownTarget.getTime() - now;

            if (distance <= 0) {
                countdownTarget = getEndOfWeekTarget();
                distance = countdownTarget.getTime() - now;
            }

            const hours = Math.floor(distance / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);

            cdHours.textContent = pad(hours);
            cdMinutes.textContent = pad(minutes);
            cdSeconds.textContent = pad(seconds);
        }

        updateCountdown();
        setInterval(updateCountdown, 1000);
    }

    /* ==========================================================================
       SERVICE CARD CLICK HANDLER (DỊCH VỤ) - demo feedback
       ========================================================================== */
    const serviceLinks = document.querySelectorAll('.service-link');
    if (serviceLinks.length > 0) {
        serviceLinks.forEach((link) => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const serviceName = link.closest('.service-card').querySelector('h3').textContent;
                console.log('Dịch vụ được chọn:', serviceName);
                // TODO: điều hướng tới trang/servlet xử lý tương ứng, ví dụ:
                // window.location.href = 'service?name=' + encodeURIComponent(serviceName);
            });
        });
    }
});
