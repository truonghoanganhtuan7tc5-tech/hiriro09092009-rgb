<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%
    // File này CHỈ đóng vai trò welcome-file cho "/".
    // Toàn bộ nội dung thật + dữ liệu nằm ở /WEB-INF/views/index.jsp,
    // được HomeServlet nạp data rồi forward tới, không truy cập trực tiếp được.
    response.sendRedirect(request.getContextPath() + "/home");
%>
